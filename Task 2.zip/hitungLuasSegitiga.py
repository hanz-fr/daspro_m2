# Nama  : Raihan Fauzi Rakhman
# NIM   : 2403872
# Kelas : 1C

alas = float(input("Input alas : "))
tinggi = float(input("Input tinggi : "))
luas = float(0.5*alas*tinggi)

print(f"Luas segitiga adalah {luas}")