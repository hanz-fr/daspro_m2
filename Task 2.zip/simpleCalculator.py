# Nama  : Raihan Fauzi Rakhman
# NIM   : 2403872
# Kelas : 1C

a = int(input("a = "))
b = int(input("b = "))
c = int(input("c = "))
sum = a+b+c

print(f"Hasil dari penjumlahan {a} + {b} + {c} = {sum}")
